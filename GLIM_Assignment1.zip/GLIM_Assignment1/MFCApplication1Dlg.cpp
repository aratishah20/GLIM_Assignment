
// MFCApplication1Dlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "MFCApplication1.h"
#include "MFCApplication1Dlg.h"
#include "afxdialogex.h"
#include <gdiplus.h>

using namespace Gdiplus;
#pragma comment(lib, "gdiplus.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CMFCApplication1Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_INIT, &CMFCApplication1Dlg::OnBnClickedButtonInit)
	ON_EN_CHANGE(IDC_EDIT_THICKNESS, &CMFCApplication1Dlg::OnEnChangeEditThickness)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_NCHITTEST()
	ON_EN_CHANGE(IDC_EDIT_RADIUS, &CMFCApplication1Dlg::OnEnChangeEditRadius)
	ON_STN_CLICKED(IDC_STATIC_P3, &CMFCApplication1Dlg::OnStnClickedStaticP3)
END_MESSAGE_MAP()

// CMFCApplication1Dlg dialog



CMFCApplication1Dlg::CMFCApplication1Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MFCAPPLICATION1_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	clickCount = 0;
	isDragging = false;
	dragIndex = -1;
	isGardenDrawn = false;
	radius = 30;      // default
	thickness = 5;    // default
}

void CMFCApplication1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

// CMFCApplication1Dlg message handlers

BOOL CMFCApplication1Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.
	//link Controls
	m_editRadius.SubclassDlgItem(IDC_EDIT_RADIUS, this);
	m_editThickness.SubclassDlgItem(IDC_EDIT_THICKNESS, this);
	m_staticP1.SubclassDlgItem(IDC_STATIC_P1, this);
	m_staticP2.SubclassDlgItem(IDC_STATIC_P2, this);
	m_staticP3.SubclassDlgItem(IDC_STATIC_P3, this);
	//default values
	m_editRadius.SetWindowTextW(_T("30"));
	m_editThickness.SetWindowTextW(_T("5"));
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFCApplication1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
// 
void CMFCApplication1Dlg::OnPaint()
{
	CPaintDC dc(this);  // Device context for painting
	Graphics graphics(dc.m_hDC);  // GDI+ object

	// Read radius & thickness from Edit Boxes
	CString str;
	m_editRadius.GetWindowTextW(str);
	radius = _ttoi(str);
	m_editThickness.GetWindowTextW(str);
	thickness = _ttoi(str);

	Pen dotPen(Color(255, 0, 0, 0), 2);  // Small black dots
	Pen gardenPen(Color(255, 0, 0, 0), (REAL)thickness);  // Black garden with thicker edge

	SolidBrush dotBrush(Color(255, 0, 0, 0));  // Black color
	// Draw small black dots for each clicked point (Red is now changed to black and a dot)
	for (int i = 0; i < clickCount && i < 3; i++)
	{
		int x = clickPoints[i].x;
		int y = clickPoints[i].y;
		graphics.FillEllipse(&dotBrush, (REAL)(x - 5), (REAL)(y - 5), 10.0f, 10.0f);//graphics.FillEllipse(&dotPen, x - 5, y - 5, 10, 10);  // Small black dot with radius 2
	}

	// Draw the green (now black) garden circle if 3 points exist
	if (clickCount == 3)
	{
		CPoint center;
		int r;
		if (CalculateCircle(clickPoints[0], clickPoints[1], clickPoints[2], center, r))
		{
			graphics.DrawEllipse(&gardenPen, center.x - r, center.y - r, r * 2, r * 2);  // Thicker black circle
		}
	}
}

//void CMFCApplication1Dlg::OnPaint()
//{
//	if (IsIconic())
//	{
//		CPaintDC dc(this); // device context for painting
//
//		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
//
//		// Center icon in client rectangle
//		int cxIcon = GetSystemMetrics(SM_CXICON);
//		int cyIcon = GetSystemMetrics(SM_CYICON);
//		CRect rect;
//		GetClientRect(&rect);
//		int x = (rect.Width() - cxIcon + 1) / 2;
//		int y = (rect.Height() - cyIcon + 1) / 2;
//
//		// Draw the icon
//		dc.DrawIcon(x, y, m_hIcon);
//	}
//	else
//	{
//		CDialogEx::OnPaint();
//	}
//}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFCApplication1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CMFCApplication1Dlg::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
void CMFCApplication1Dlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	//MessageBox(_T("You clicked!"));

	if (clickCount < 3)
	{
		clickPoints[clickCount] = point;
		clickCount++;

		CString str;
		str.Format(_T("X: %d, Y: %d"), point.x, point.y);

		if (clickCount == 1)
			m_staticP1.SetWindowTextW(str);
		else if (clickCount == 2)
			m_staticP2.SetWindowTextW(str);
		else if (clickCount == 3)
			m_staticP3.SetWindowTextW(str);

		Invalidate(); // Redraw the screen
	}
	else
	{
		// After 3 clicks: allow dragging
		for (int i = 0; i < 3; i++)
		{
			if (abs(point.x - clickPoints[i].x) < 10 && abs(point.y - clickPoints[i].y) < 10)
			{
				isDragging = true;
				dragIndex = i;
				break;
			}
		}
	}

	CDialogEx::OnLButtonDown(nFlags, point);  // base class call
}


void CMFCApplication1Dlg::OnMouseMove(UINT nFlags, CPoint point)
{
	if (isDragging && dragIndex >= 0 && dragIndex < 3)
	{
		clickPoints[dragIndex] = point;
		Invalidate(); // Redraw when dragging
	}

	CDialogEx::OnMouseMove(nFlags, point);
}

void CMFCApplication1Dlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	isDragging = false;
	dragIndex = -1;

	CDialogEx::OnLButtonUp(nFlags, point);
}

void CMFCApplication1Dlg::OnBnClickedButtonInit()
{
	// Reset points and click count
	clickCount = 0;
	isDragging = false;
	dragIndex = -1;
	Invalidate(); // Redraw the screen to clear the previous drawing
}


void CMFCApplication1Dlg::OnEnChangeEditThickness()
{
	// Get the new thickness value from the edit box
	CString str;
	m_editThickness.GetWindowTextW(str);
	thickness = _ttoi(str); // Convert it to an integer

	// Redraw the window to reflect the new thickness
	Invalidate(); // Redraw the screen
}


void CMFCApplication1Dlg::OnStnClickedStaticP1()
{
	// TODO: Add your control notification handler code here
}

LRESULT CMFCApplication1Dlg::OnNcHitTest(CPoint point)
{
	LRESULT result = CDialogEx::OnNcHitTest(point);
	if (result == HTCLIENT)
		return result;

	return HTCLIENT;
}

void CMFCApplication1Dlg::OnEnChangeEditRadius()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

void CMFCApplication1Dlg::OnStnClickedStaticP3()
{
	// TODO: Add your control notification handler code here
}

bool CMFCApplication1Dlg::CalculateCircle(CPoint p1, CPoint p2, CPoint p3, CPoint& center, int& radius)
{
	double x1 = p1.x, y1 = p1.y;
	double x2 = p2.x, y2 = p2.y;
	double x3 = p3.x, y3 = p3.y;

	double a = x1 * (y2 - y3) - y1 * (x2 - x3) + x2 * y3 - x3 * y2;
	if (fabs(a) < 1e-6)
		return false;

	double b = ((x1 * x1 + y1 * y1) * (y3 - y2) + (x2 * x2 + y2 * y2) * (y1 - y3) + (x3 * x3 + y3 * y3) * (y2 - y1));
	double c = ((x1 * x1 + y1 * y1) * (x2 - x3) + (x2 * x2 + y2 * y2) * (x3 - x1) + (x3 * x3 + y3 * y3) * (x1 - x2));

	center.x = static_cast<int>(-b / (2 * a));
	center.y = static_cast<int>(-c / (2 * a));
	radius = static_cast<int>(sqrt((center.x - x1) * (center.x - x1) + (center.y - y1) * (center.y - y1)));

	return true;
}


