
// MFCApplication1Dlg.h : header file
//

#pragma once


// CMFCApplication1Dlg dialog
class CMFCApplication1Dlg : public CDialogEx
{
// Construction
public:
	CMFCApplication1Dlg(CWnd* pParent = nullptr);	// standard constructor
	CEdit m_editRadius;
	CEdit m_editThickness;
	CStatic m_staticP1;
	CStatic m_staticP2;
	CStatic m_staticP3;

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCAPPLICATION1_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg LRESULT OnNcHitTest(CPoint point);

	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

	//Variables
private:
	CPoint clickPoints[3];
	int clickCount;
	bool isDragging;
	int dragIndex;
	bool isGardenDrawn;
	int radius;
	int thickness;
	bool CalculateCircle(CPoint p1, CPoint p2, CPoint p3, CPoint& center, int& radius);

public:
	afx_msg void OnEnChangeEdit1();
	//afx_msg LRESULT OnNcHitTest(CPoint point);

	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnEnChangeEditThickness();
	afx_msg void OnStnClickedStaticP1();
	afx_msg void OnEnChangeEditRadius();
	afx_msg void OnStnClickedStaticP3();
};
